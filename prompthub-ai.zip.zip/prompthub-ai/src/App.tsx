import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ToolCards } from './components/ToolCards';
import { ImagePromptTool } from './components/ImagePromptTool';
import { VideoPromptTool } from './components/VideoPromptTool';
import { ScriptStudio } from './components/ScriptStudio';
import { TrendingSection } from './components/TrendingSection';
import { PromptLibrary } from './components/PromptLibrary';
import { PrivacyPolicy } from './components/PrivacyPolicy';
import { AboutContact } from './components/AboutContact';
import { AdBanner } from './components/AdBanner';
import { SavedPromptsModal } from './components/SavedPromptsModal';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';
import { ActiveTab, SavedPromptItem } from './types';
import { admobService } from './services/admobService';
import { ArrowLeft, Image as ImageIcon, Video as VideoIcon, Clapperboard, Sparkles, Mail, ArrowRight } from 'lucide-react';

const LOCAL_STORAGE_KEY = 'prompthub_saved_prompts_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [homeStudio, setHomeStudio] = useState<'image' | 'video' | 'script'>('image');
  const [savedPrompts, setSavedPrompts] = useState<SavedPromptItem[]>([]);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [preloadedPrompt, setPreloadedPrompt] = useState<string>('');

  // Toast state
  const [toast, setToast] = useState<{
    message: string;
    subMessage?: string;
    type: 'success' | 'info' | 'copy';
  } | null>(null);

  // Initialize native AdMob (when running as Android app via Capacitor)
  useEffect(() => {
    try {
      admobService.initialize().catch(() => {});
    } catch {
      // Gracefully bypass in web preview
    }
  }, []);

  // Load saved prompts from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (stored) {
        setSavedPrompts(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Failed to load saved prompts', e);
    }
  }, []);

  // Sync to localStorage
  const updateSavedPrompts = (updater: (prev: SavedPromptItem[]) => SavedPromptItem[]) => {
    setSavedPrompts((prev) => {
      const next = updater(prev);
      try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(next));
      } catch (e) {
        console.error('Failed to persist saved prompts', e);
      }
      return next;
    });
  };

  const showToast = (message: string, subMessage?: string, type: 'success' | 'info' | 'copy' = 'copy') => {
    setToast({ message, subMessage, type });
  };

  const handleCopyToast = (text: string, label: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    showToast('Copied to clipboard!', `${label} ready to paste`, 'copy');
  };

  const handleSavePrompt = (item: Omit<SavedPromptItem, 'id' | 'createdAt'>) => {
    const newItem: SavedPromptItem = {
      ...item,
      id: `prompt-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: Date.now(),
    };

    updateSavedPrompts((prev) => [newItem, ...prev]);
    showToast('Saved to your collection!', item.title, 'success');
  };

  const handleDeleteSavedPrompt = (id: string) => {
    updateSavedPrompts((prev) => prev.filter((p) => p.id !== id));
    showToast('Prompt removed', undefined, 'info');
  };

  const handleClearAllSaved = () => {
    if (window.confirm('Are you sure you want to remove all saved prompts?')) {
      updateSavedPrompts(() => []);
      showToast('Collection cleared', undefined, 'info');
    }
  };

  const handleUseInTool = (prompt: string, tool: 'image' | 'video' | 'script') => {
    setPreloadedPrompt(prompt);
    if (tool === 'image') setActiveTab('image-tool');
    else if (tool === 'video') setActiveTab('video-tool');
    else setActiveTab('script-tool');

    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast('Prompt loaded into Studio', 'Customize parameters and generate', 'info');
  };

  // Auto-dismiss toast
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        savedCount={savedPrompts.length}
        openSavedModal={() => setIsSavedModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <Hero setActiveTab={setActiveTab} />

            {/* Live Interactive Studio on Homepage */}
            <div id="live-studio" className="max-w-6xl mx-auto px-4 sm:px-6 mb-12">
              <div className="bg-[#0f172a]/70 border border-white/10 rounded-3xl p-4 sm:p-6 shadow-2xl backdrop-blur-xl">
                {/* Studio Header & Tab Switcher */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 mb-2 border-b border-white/5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center">
                      <Sparkles className="w-4 h-4 animate-spin-slow" />
                    </div>
                    <div>
                      <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                        <span>Live Generation Studio</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          Active & Free
                        </span>
                      </h2>
                      <p className="text-xs text-slate-400">Select any tool below to generate prompts immediately</p>
                    </div>
                  </div>

                  {/* 3 Tool Tabs */}
                  <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0b0f17] border border-white/10 overflow-x-auto">
                    <button
                      onClick={() => setHomeStudio('image')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        homeStudio === 'image'
                          ? 'bg-violet-600/30 text-violet-200 border border-violet-500/40 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-violet-400" />
                      <span>1. Image Prompts</span>
                    </button>

                    <button
                      onClick={() => setHomeStudio('video')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        homeStudio === 'video'
                          ? 'bg-cyan-600/30 text-cyan-200 border border-cyan-500/40 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <VideoIcon className="w-3.5 h-3.5 text-cyan-400" />
                      <span>2. Video Prompts</span>
                    </button>

                    <button
                      onClick={() => setHomeStudio('script')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        homeStudio === 'script'
                          ? 'bg-rose-600/30 text-rose-200 border border-rose-500/40 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Clapperboard className="w-3.5 h-3.5 text-rose-400" />
                      <span>3. Script Studio</span>
                    </button>
                  </div>
                </div>

                {/* Active Tool Body */}
                {homeStudio === 'image' && (
                  <ImagePromptTool
                    initialPrompt={preloadedPrompt}
                    onCopy={handleCopyToast}
                    onSave={handleSavePrompt}
                  />
                )}
                {homeStudio === 'video' && (
                  <VideoPromptTool
                    initialPrompt={preloadedPrompt}
                    onCopy={handleCopyToast}
                    onSave={handleSavePrompt}
                  />
                )}
                {homeStudio === 'script' && (
                  <ScriptStudio
                    initialPrompt={preloadedPrompt}
                    onCopy={handleCopyToast}
                    onSave={handleSavePrompt}
                  />
                )}
              </div>
            </div>

            <ToolCards setActiveTab={(tab) => {
              if (tab === 'image-tool') setHomeStudio('image');
              else if (tab === 'video-tool') setHomeStudio('video');
              else if (tab === 'script-tool') setHomeStudio('script');
              // Also scroll up to live studio
              const el = document.getElementById('live-studio');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
              else setActiveTab(tab);
            }} />

            {/* Non-intrusive Ad Placement Area: Home Page */}
            <AdBanner slotId="homeBanner" />

            <TrendingSection onCopy={handleCopyToast} onUseInTool={(prompt, tool) => {
              setPreloadedPrompt(prompt);
              setHomeStudio(tool);
              const el = document.getElementById('live-studio');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
              showToast('Prompt loaded into Studio', 'Customize parameters and generate', 'info');
            }} />
            <PromptLibrary onCopy={handleCopyToast} onUseInTool={(prompt, tool) => {
              setPreloadedPrompt(prompt);
              setHomeStudio(tool);
              const el = document.getElementById('live-studio');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
              showToast('Prompt loaded into Studio', 'Customize parameters and generate', 'info');
            }} />

            {/* About PromptHub AI & Support Section on Homepage */}
            <section className="max-w-6xl mx-auto px-4 sm:px-6 mb-16">
              <div className="bg-[#0f172a]/70 border border-white/10 rounded-3xl p-6 sm:p-8 backdrop-blur-xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-2xl">
                <div className="space-y-2 max-w-2xl">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 block">
                    About PromptHub AI
                  </span>
                  <h3 className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug">
                    PromptHub AI is an AI-powered platform that helps users create high-quality prompts for images and videos, write scripts, and discover trending content ideas.
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Have questions, feedback, or need technical help? Contact the app owner anytime.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                  <button
                    onClick={() => { setActiveTab('about'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                    className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-all shadow-lg shadow-cyan-950/50 flex items-center gap-1.5"
                  >
                    <span>About & Contact Support</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <a
                    href="mailto:ak47awaisk786@gmail.com"
                    className="px-3.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-medium transition-colors flex items-center gap-1.5"
                  >
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span>Email Owner</span>
                  </a>
                </div>
              </div>
            </section>
          </>
        )}

        {activeTab === 'image-tool' && (
          <div>
            <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-6">
              <button
                onClick={() => setActiveTab('home')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to PromptHub AI Overview
              </button>
            </div>
            <ImagePromptTool
              key={preloadedPrompt}
              initialPrompt={preloadedPrompt}
              onCopy={handleCopyToast}
              onSave={handleSavePrompt}
            />
            {/* Non-intrusive Ad Placement Area: Tool Results Page */}
            <AdBanner slotId="studioResultsBanner" />
          </div>
        )}

        {activeTab === 'video-tool' && (
          <div>
            <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-6">
              <button
                onClick={() => setActiveTab('home')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to PromptHub AI Overview
              </button>
            </div>
            <VideoPromptTool
              key={preloadedPrompt}
              initialPrompt={preloadedPrompt}
              onCopy={handleCopyToast}
              onSave={handleSavePrompt}
            />
            {/* Non-intrusive Ad Placement Area: Tool Results Page */}
            <AdBanner slotId="studioResultsBanner" />
          </div>
        )}

        {activeTab === 'script-tool' && (
          <div>
            <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-6">
              <button
                onClick={() => setActiveTab('home')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to PromptHub AI Overview
              </button>
            </div>
            <ScriptStudio
              key={preloadedPrompt}
              initialPrompt={preloadedPrompt}
              onCopy={handleCopyToast}
              onSave={handleSavePrompt}
            />
            {/* Non-intrusive Ad Placement Area: Tool Results Page */}
            <AdBanner slotId="studioResultsBanner" />
          </div>
        )}

        {activeTab === 'trending' && (
          <div className="pt-4">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
              <button
                onClick={() => setActiveTab('home')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to Overview
              </button>
            </div>
            <TrendingSection onCopy={handleCopyToast} onUseInTool={handleUseInTool} />
          </div>
        )}

        {activeTab === 'library' && (
          <div className="pt-4">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
              <button
                onClick={() => setActiveTab('home')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to Overview
              </button>
            </div>
            <PromptLibrary onCopy={handleCopyToast} onUseInTool={handleUseInTool} />
          </div>
        )}

        {activeTab === 'privacy' && (
          <PrivacyPolicy onBack={() => { setActiveTab('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />
        )}

        {activeTab === 'about' && (
          <AboutContact
            onBack={() => { setActiveTab('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
            onNavigateTab={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </main>

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

      {/* Saved Prompts Modal */}
      <SavedPromptsModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedPrompts={savedPrompts}
        onDeletePrompt={handleDeleteSavedPrompt}
        onClearAll={handleClearAllSaved}
        onCopy={handleCopyToast}
      />

      {/* Floating Toast Notification */}
      {toast && (
        <Toast
          message={toast.message}
          subMessage={toast.subMessage}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
